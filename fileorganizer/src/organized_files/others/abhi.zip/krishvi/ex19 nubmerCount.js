var ar = [-1, -2, -3, 0, 0, 5, 12, 0, -10];

function counter(ar) {
  var counter = [0, 0, 0];
  ar.forEach(function(a) {
    if (a < 0)
      counter[0]++;
    else if (a > 0)
      counter[2]++;
    else
      counter[1]++;
  });
  return counter;
}

var result = counter(ar);
console.log("No of Negative, Zero and Positive Elements are : " + result);